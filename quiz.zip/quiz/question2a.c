#include <sys/stat.h>
#include <sys/types.h>

int main(){
    // create new directory using mkir system call
int result = mkdir("/home/yared/Videos/yared", 0777);
}